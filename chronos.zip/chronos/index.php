<?php require 'inc.php'; if (logado()) { header('Location: catalogo.php'); exit; } topo('Início'); ?>
<section class="hero"><div>
<h1>O passado nunca esteve tão perto.</h1>
<p>CRONOS é um streaming de história mundial e do Brasil. Civilizações antigas, guerras, grandes personagens e descobertas que mudaram o mundo, tudo reunido em um só lugar.</p>
<a class="btn" href="cadastro.php">Criar minha conta</a>
<a class="btn sec" href="login.php">Já tenho conta</a></div></section>
<section class="sobre">
<h2>Como funciona</h2>
<div class="sobre-grid">
<article><h3>Explore</h3><p>15 temas divididos em 5 categorias: Civilizações Antigas, Guerras e Conflitos, História do Brasil, Personagens Históricos e Mistérios e Descobertas.</p></article>
<article><h3>Busque</h3><p>Encontre qualquer assunto por título, período ou palavra-chave, e filtre por categoria sem recarregar a página.</p></article>
<article><h3>Salve</h3><p>Favorite os conteúdos que mais gostou e acesse tudo depois na sua lista pessoal.</p></article>
</div>
<p class="chamada">Crie uma conta gratuita ou entre para acessar o catálogo.</p>
</section>
<?php rodape(); ?>
