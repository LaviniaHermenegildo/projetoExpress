<?php
require 'inc.php';
garantir_tabela_reset();
$token = $_GET['token'] ?? $_POST['token'] ?? '';
$hash = preg_match('/^[a-f0-9]{64}$/', $token) ? hash('sha256', $token) : '';
$reg = false;
if ($hash) {
  $q = db()->prepare('SELECT id, usuario_id FROM reset_senha WHERE token_hash=? AND usado=0 AND expira_em > NOW()');
  $q->execute([$hash]); $reg = $q->fetch(PDO::FETCH_ASSOC);
}
$erro = ''; $feito = false;
if ($reg && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $s1 = $_POST['senha'] ?? ''; $s2 = $_POST['senha2'] ?? '';
  if (strlen($s1) < 6) $erro = 'A senha precisa ter 6 ou mais caracteres.';
  elseif ($s1 !== $s2) $erro = 'As senhas não são iguais.';
  else {
    db()->prepare('UPDATE usuarios SET senha=? WHERE id=?')->execute([password_hash($s1, PASSWORD_DEFAULT), $reg['usuario_id']]);
    db()->prepare('UPDATE reset_senha SET usado=1 WHERE usuario_id=?')->execute([$reg['usuario_id']]);
    $feito = true;
  }
}
topo('Nova senha'); ?>
<section class="form-box"><h1>Nova senha</h1>
<?php if ($feito): ?>
<p class="ok">Senha alterada com sucesso.</p><p class="aux"><a class="btn" href="login.php">Entrar</a></p>
<?php elseif (!$reg): ?>
<p class="erro">Este link é inválido ou já expirou.</p><p class="aux"><a href="recuperar.php">Pedir um novo link</a></p>
<?php else: ?>
<?php if ($erro): ?><p class="erro"><?= e($erro) ?></p><?php endif; ?>
<form method="post"><input type="hidden" name="token" value="<?= e($token) ?>">
<label>Nova senha<input type="password" name="senha" minlength="6" required></label>
<label>Repita a senha<input type="password" name="senha2" minlength="6" required></label>
<button class="btn">Salvar senha</button></form>
<?php endif; ?>
</section>
<?php rodape(); ?>
