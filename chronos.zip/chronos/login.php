<?php
require 'inc.php';
if (logado()) { header('Location: catalogo.php'); exit; }
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $q = db()->prepare('SELECT * FROM usuarios WHERE email=?'); $q->execute([strtolower(trim($_POST['email'] ?? ''))]);
  $u = $q->fetch(PDO::FETCH_ASSOC);
  if ($u && password_verify($_POST['senha'] ?? '', $u['senha'])) {
    session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id']; $_SESSION['nome'] = $u['nome'];
    header('Location: catalogo.php'); exit;
  }
  $erro = 'E-mail ou senha incorretos.';
}
topo('Entrar'); ?>
<section class="form-box"><h1>Entrar</h1>
<?php if ($erro): ?><p class="erro"><?= e($erro) ?></p><?php endif; ?>
<form method="post"><label>E-mail<input type="email" name="email" required></label>
<label>Senha<input type="password" name="senha" required></label>
<button class="btn">Entrar</button></form>
<p class="aux"><a href="recuperar.php">Esqueci minha senha</a> · <a href="cadastro.php">Cadastrar</a></p></section>
<?php rodape(); ?>
