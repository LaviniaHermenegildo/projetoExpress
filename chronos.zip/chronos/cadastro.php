<?php
require 'inc.php';
if (logado()) { header('Location: catalogo.php'); exit; }
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome = trim($_POST['nome'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $senha = $_POST['senha'] ?? '';
  if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($senha) < 6) $erro = 'Preencha o nome, um e-mail válido e uma senha com 6 ou mais caracteres.';
  else {
    $q = db()->prepare('SELECT id FROM usuarios WHERE email=?'); $q->execute([$email]);
    if ($q->fetch()) $erro = 'Este e-mail já está cadastrado.';
    else {
      db()->prepare('INSERT INTO usuarios (nome,email,senha) VALUES (?,?,?)')->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
      $novo = (int)db()->lastInsertId();
      avisar_dono($nome, $email);
      session_regenerate_id(true); $_SESSION['uid'] = $novo; $_SESSION['nome'] = $nome;
      header('Location: catalogo.php'); exit;
    }
  }
}
topo('Cadastrar'); ?>
<section class="form-box"><h1>Cadastrar</h1>
<?php if ($erro): ?><p class="erro"><?= e($erro) ?></p><?php endif; ?>
<form method="post"><label>Nome<input name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></label>
<label>E-mail<input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label>
<label>Senha<input type="password" name="senha" minlength="6" required></label>
<button class="btn">Cadastrar</button></form>
<p class="aux">Já tem conta? <a href="login.php">Entrar</a></p></section>
<?php rodape(); ?>
