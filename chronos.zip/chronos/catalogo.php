<?php require 'inc.php'; exige(); topo('Catálogo'); ?>
<section id="catalogo" class="conteudo">
<h1 class="tit-pag">Catálogo</h1>
<input id="busca" type="search" placeholder="Buscar por título, período ou assunto" aria-label="Buscar">
<div id="chips" class="chips"></div>
<div id="lista"></div></section>
<?php rodape(); ?>
