<?php
require 'inc.php';
header('Content-Type: application/json');
if (!logado()) { http_response_code(401); echo '{}'; exit; }
$id = (int)($_GET['id'] ?? 0);
$q  = trim($_GET['q'] ?? '');
if ($id < 1 || $id > 15 || $q === '' || mb_strlen($q) > 120) { http_response_code(400); echo '{}'; exit; }

db()->exec('CREATE TABLE IF NOT EXISTS videos (conteudo_id INT PRIMARY KEY, video_id VARCHAR(20) NOT NULL, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP)');

$s = db()->prepare('SELECT video_id FROM videos WHERE conteudo_id=?'); $s->execute([$id]);
$v = $s->fetchColumn();
if ($v) { echo json_encode(['id' => $v]); exit; }

if (!function_exists('curl_init') || YOUTUBE_KEY === '' || strpos(YOUTUBE_KEY, 'COLE_') === 0) { echo json_encode(['id' => null, 'erro' => 'sem_chave']); exit; }
$url = 'https://www.googleapis.com/youtube/v3/search?' . http_build_query([
  'part' => 'snippet', 'type' => 'video', 'maxResults' => 1, 'q' => $q,
  'videoEmbeddable' => 'true', 'videoSyndicated' => 'true', 'safeSearch' => 'strict',
  'relevanceLanguage' => 'pt', 'regionCode' => 'BR', 'key' => YOUTUBE_KEY,
]);
$c = curl_init($url);
curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8]);
$r = curl_exec($c); curl_close($c);
$j = $r ? json_decode($r, true) : null;
$v = $j['items'][0]['id']['videoId'] ?? null;
if ($v && preg_match('/^[A-Za-z0-9_-]{6,20}$/', $v)) {
  db()->prepare('INSERT IGNORE INTO videos (conteudo_id, video_id) VALUES (?,?)')->execute([$id, $v]);
  echo json_encode(['id' => $v]);
} else {
  echo json_encode(['id' => null]);
}
