<?php
require 'inc.php';
$msg = ''; $erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = strtolower(trim($_POST['email'] ?? ''));
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erro = 'Digite um e-mail válido.';
  else {
    garantir_tabela_reset();
    $q = db()->prepare('SELECT id, nome FROM usuarios WHERE email=?'); $q->execute([$email]);
    if ($u = $q->fetch(PDO::FETCH_ASSOC)) {
      $token = bin2hex(random_bytes(32));
      db()->prepare('UPDATE reset_senha SET usado=1 WHERE usuario_id=?')->execute([$u['id']]);
      db()->prepare('INSERT INTO reset_senha (usuario_id, token_hash, expira_em) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))')
        ->execute([$u['id'], hash('sha256', $token)]);
      $link = rtrim(BASE_URL, '/') . '/redefinir.php?token=' . $token;
      enviar_email($email, 'Redefinir sua senha no CRONOS',
        '<p>Olá, ' . e($u['nome']) . '!</p><p>Recebemos um pedido para redefinir a sua senha no CRONOS.</p>'
        . '<p><a href="' . e($link) . '" style="background:#D8B66A;color:#090A0C;padding:10px 18px;text-decoration:none;border-radius:4px;font-weight:bold">Criar nova senha</a></p>'
        . '<p>O link vale por 1 hora. Se não foi você, é só ignorar este e-mail.</p>');
    }
    $msg = 'Se este e-mail estiver cadastrado, enviamos um link para criar uma nova senha. Confira também o spam.';
  }
}
topo('Recuperar senha'); ?>
<section class="form-box"><h1>Recuperar senha</h1>
<?php if ($msg): ?><p class="ok"><?= e($msg) ?></p><?php endif; ?>
<?php if ($erro): ?><p class="erro"><?= e($erro) ?></p><?php endif; ?>
<form method="post"><label>E-mail da conta<input type="email" name="email" required></label>
<button class="btn">Enviar link</button></form>
<p class="aux"><a href="login.php">Voltar ao login</a></p></section>
<?php rodape(); ?>
