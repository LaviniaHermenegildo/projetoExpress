<?php
require 'inc.php';
header('Content-Type: application/json');
if (!logado() || $_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(401); echo '{}'; exit; }
$id = (int)($_POST['id'] ?? 0);
if ($id < 1 || $id > 15) { http_response_code(400); echo '{}'; exit; }
$u = $_SESSION['uid'];
$q = db()->prepare('SELECT 1 FROM favoritos WHERE usuario_id=? AND conteudo_id=?');
$q->execute([$u, $id]);
if ($q->fetch()) { db()->prepare('DELETE FROM favoritos WHERE usuario_id=? AND conteudo_id=?')->execute([$u, $id]); echo '{"fav":false}'; }
else { db()->prepare('INSERT INTO favoritos (usuario_id, conteudo_id) VALUES (?,?)')->execute([$u, $id]); echo '{"fav":true}'; }
