<?php require 'inc.php'; exige(); $modo = 'fav'; topo('Favoritos'); ?>
<section class="conteudo"><h1>Meus favoritos</h1><div id="lista"></div></section>
<?php rodape(); ?>
