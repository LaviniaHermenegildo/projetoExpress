const CATS = ["Civilizações Antigas", "Guerras e Conflitos", "História do Brasil", "Personagens Históricos", "Mistérios e Descobertas"];
const RAW = [
[0,"Pirâmides de Gizé","c. 2600 a.C.","As grandes tumbas dos faraós e como foram construídas.","As pirâmides de Gizé foram erguidas há mais de 4.500 anos como tumbas dos faraós Quéops, Quéfren e Miquerinos. A Grande Pirâmide, de Quéops, foi por séculos a construção mais alta do mundo e reuniu milhares de trabalhadores organizados pelo Estado egípcio. Até hoje ela impressiona pela precisão da engenharia."],
[0,"O Império Romano","27 a.C.–476 d.C.","De Augusto à queda do Império do Ocidente.","Começou em 27 a.C., quando Augusto se tornou o primeiro imperador, e chegou a dominar todo o Mediterrâneo. Roma deixou legados em leis, idioma, estradas e arquitetura. O Império do Ocidente caiu em 476 d.C., enfraquecido por crises internas e invasões."],
[0,"Atenas e a Democracia","séc. V a.C.","O nascimento da participação política dos cidadãos.","No século V a.C., Atenas criou um sistema em que os cidadãos votavam diretamente as decisões da cidade, na assembleia chamada Eclésia. Mulheres, escravizados e estrangeiros ficavam de fora. Mesmo limitada, essa experiência inspirou as democracias modernas."],
[1,"Primeira Guerra Mundial","1914–1918","As trincheiras e o fim de quatro impérios.","Começou em 1914, depois do assassinato do arquiduque Francisco Ferdinando, e envolveu as grandes potências europeias. Foi marcada pelas trincheiras, pelo uso de armas novas, como metralhadoras e gás, e por milhões de mortos. Terminou em 1918 e redesenhou o mapa da Europa."],
[1,"Segunda Guerra Mundial","1939–1945","O maior conflito do século XX e suas consequências.","Entre 1939 e 1945, os Aliados enfrentaram a Alemanha nazista, a Itália fascista e o Japão. O conflito teve batalhas em vários continentes e o Holocausto, que exterminou milhões de judeus e outras vítimas. Acabou com as bombas atômicas e deu origem à ONU."],
[1,"Guerra Fria","1947–1991","A disputa entre Estados Unidos e União Soviética.","Depois de 1945, Estados Unidos e União Soviética disputaram influência no mundo sem lutar diretamente entre si. A rivalidade apareceu na corrida armamentista, na corrida espacial e em conflitos como Coreia e Vietnã. Terminou com o fim da URSS, em 1991."],
[2,"Independência do Brasil","1822","O processo que separou o Brasil de Portugal.","Em 7 de setembro de 1822, às margens do Ipiranga, Dom Pedro I proclamou a separação entre Brasil e Portugal. O processo vinha da vinda da família real em 1808 e das tensões com as Cortes portuguesas. Portugal só reconheceu a independência em 1825."],
[2,"Abolição da Escravidão","1888","A Lei Áurea e o fim de um sistema de séculos.","A Lei Áurea, assinada pela princesa Isabel em 13 de maio de 1888, encerrou oficialmente a escravidão no Brasil, o último país das Américas a fazê-lo. A lei foi resultado de décadas de luta de abolicionistas e de resistência dos próprios escravizados. Não garantiu terra, trabalho nem inclusão aos libertos."],
[2,"Era Vargas","1930–1945","Industrialização, direitos trabalhistas e Estado Novo.","Entre 1930 e 1945, Getúlio Vargas governou o Brasil em três fases: governo provisório, governo constitucional e Estado Novo, uma ditadura. O período trouxe a CLT, o salário mínimo e o impulso à indústria, junto com censura e repressão. Vargas foi deposto em 1945."],
[3,"Cleópatra VII","69–30 a.C.","A última rainha do Egito ptolomaico.","Última rainha do Egito ptolomaico, governou entre 51 e 30 a.C. Falava vários idiomas e usou alianças com Júlio César e Marco Antônio para manter o reino independente de Roma. Após a derrota na batalha de Áccio, o Egito se tornou província romana."],
[3,"Napoleão Bonaparte","1769–1821","Do general revolucionário ao imperador francês.","Militar nascido na Córsega, ganhou destaque na Revolução Francesa e se tornou imperador em 1804. Conquistou boa parte da Europa e criou o Código Civil napoleônico. Foi derrotado em Waterloo, em 1815, e morreu exilado na ilha de Santa Helena."],
[3,"Santos Dumont","1873–1932","O brasileiro pioneiro da aviação.","Nascido em Minas Gerais, tornou-se pioneiro da aviação em Paris. Em 1901, contornou a Torre Eiffel de dirigível e, em 1906, voou com o 14-Bis, diante de testemunhas. No Brasil, é reconhecido como o pai da aviação."],
[4,"Pompeia","79 d.C.","A cidade romana preservada pela erupção do Vesúvio.","Em 79 d.C., a erupção do Vesúvio soterrou a cidade romana de Pompeia sob cinzas e pedras-pomes. A camada de material preservou ruas, casas, afrescos e até os moldes dos corpos das vítimas. Hoje as escavações mostram como era o cotidiano em Roma."],
[4,"O Túmulo de Tutancâmon","1922","A descoberta de Howard Carter no Vale dos Reis.","Em 1922, o arqueólogo Howard Carter encontrou no Vale dos Reis o túmulo de Tutancâmon, quase intacto. Dentro havia milhares de objetos, entre eles a famosa máscara de ouro. A descoberta renovou o interesse mundial pelo Egito antigo e alimentou a lenda da maldição do faraó."],
[4,"Machu Picchu","1911","A cidade inca e sua divulgação ao mundo moderno.","Cidadela inca construída no século XV, nos Andes peruanos, a mais de 2.400 metros de altitude. Foi abandonada e ficou escondida da maior parte do mundo até 1911, quando o explorador Hiram Bingham a divulgou. Hoje é Patrimônio Mundial e uma das Sete Maravilhas do Mundo Moderno."]
];

const VIDEOS = {
  1: "ayrAuNLct4k",
  2: "hxw_uEXIPVA",
  3: "3pidndezays",
  4: "TAbyRJIyC1A",
  5: "ScKpRUQ7sXs",
  6: "6QOkLu4kOOI",
  7: "jw2aI2_xb08",
  8: "GiZEG8ec0kU",
  9: "sc2KBgUCEYg",
  10: "YOXPlnOhbO0",
  11: "izFQmzMv1nQ",
  12: "dFfrA6dtcRg",
  13: "VkzinCC_qro",
  14: "AhMw0Frpuo8",
  15: "FJKhHXbXxLY"
};
const ITENS = RAW.map((r, i) => ({ id: i + 1, cat: r[0], titulo: r[1], periodo: r[2], desc: r[3], resumo: r[4] }));
