const $ = s => document.querySelector(s);
const F = new Set(window.FAVS || []);
const norm = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
const capa = i => `<div class="capa" data-id="${i.id}" style="--h:${(i.id * 47) % 360}"><span>${i.periodo}</span></div>`;
const card = i => `<article class="card"><a href="detalhe.php?id=${i.id}">${capa(i)}<h3>${i.titulo}</h3><p>${i.desc}</p></a><button class="fav ${F.has(i.id) ? "on" : ""}" data-id="${i.id}" aria-label="Favoritar ${i.titulo}">♥</button></article>`;

function filtrar() {
  const q = norm($("#busca") ? $("#busca").value : "");
  const c = $(".chip.on") ? $(".chip.on").dataset.c : "";
  return ITENS.filter(i => (window.MODO !== "fav" || F.has(i.id)) && (c === "" || i.cat == c) && norm(i.titulo + " " + i.desc + " " + i.periodo + " " + i.resumo).includes(q));
}
function render() {
  const el = $("#lista"); if (!el) return;
  const its = filtrar();
  if (!its.length) { el.innerHTML = `<p class="vazio">${window.MODO === "fav" ? 'Você ainda não favoritou nada. <a href="catalogo.php">Explorar o catálogo</a>' : "Nenhum resultado. Tente outro termo ou categoria."}</p>`; return; }
  el.innerHTML = CATS.map((n, k) => { const g = its.filter(i => i.cat == k); return g.length ? `<section><h2>${n}</h2><div class="fileira">${g.map(card).join("")}</div></section>` : ""; }).join("");
}
if ($("#chips")) {
  $("#chips").innerHTML = `<button class="chip on" data-c="">Todas</button>` + CATS.map((n, k) => `<button class="chip" data-c="${k}">${n}</button>`).join("");
  $("#chips").addEventListener("click", e => { const b = e.target.closest(".chip"); if (!b) return; document.querySelectorAll(".chip").forEach(x => x.classList.remove("on")); b.classList.add("on"); render(); });
  $("#busca").addEventListener("input", render);
}

const ytBusca = i => "https://www.youtube.com/results?search_query=" + encodeURIComponent(i.titulo + " história");
async function videoDe(i) {
  if (typeof VIDEOS !== "undefined" && VIDEOS[i.id]) return VIDEOS[i.id];
  try {
    const r = await fetch("api_video.php?id=" + i.id + "&q=" + encodeURIComponent(i.titulo + " história documentário"));
    if (!r.ok) return null;
    return (await r.json()).id || null;
  } catch (e) { return null; }
}
const d = $("#detalhe");
if (d) {
  const i = ITENS.find(x => x.id == new URLSearchParams(location.search).get("id"));
  if (!i) d.innerHTML = '<p class="vazio">Conteúdo não encontrado. <a href="catalogo.php">Voltar ao catálogo</a></p>';
  else {
    const foto = v => v
      ? `<button class="play" type="button" data-v="${v}" aria-label="Assistir ao vídeo sobre ${i.titulo}"><img src="https://img.youtube.com/vi/${v}/hqdefault.jpg" alt="${i.titulo}"><span class="tri">▶</span></button>`
      : `<div class="capa-grande">${i.periodo}</div>`;
    const fixo = typeof VIDEOS !== "undefined" && VIDEOS[i.id];
    d.innerHTML = `<div class="det2"><p class="meta">${CATS[i.cat]} · ${i.periodo}</p><h1>${i.titulo}</h1>
<div id="video" class="video-box">${fixo ? foto(fixo) : ""}</div>
<p class="acoes"><a class="btn" href="${ytBusca(i)}" target="_blank" rel="noopener">Procurar vídeos desse tema no YouTube</a></p>
<h2>O que foi</h2><p class="resumo">${i.resumo}</p>
<button class="fav btn on-label ${F.has(i.id) ? "on" : ""}" data-id="${i.id}">♥ Favoritar</button></div>
<h2>Relacionados</h2><div class="fileira">${ITENS.filter(x => x.cat == i.cat && x.id != i.id).slice(0, 5).map(card).join("")}</div>`;
    document.title = i.titulo + " — CRONOS";
    if (!fixo) videoDe(i).then(v => { $("#video").innerHTML = foto(v); });
  }
}
document.addEventListener("click", async e => {
  const b = e.target.closest(".fav"); if (!b) return;
  if (!window.LOGADO) { location.href = "login.php"; return; }
  const r = await fetch("api_fav.php", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: "id=" + b.dataset.id });
  if (!r.ok) return;
  const j = await r.json(), id = +b.dataset.id;
  j.fav ? F.add(id) : F.delete(id);
  b.classList.toggle("on", j.fav);
  if (window.MODO === "fav") render();
});
render();

document.addEventListener("click", ev => {
  const p = ev.target.closest(".play");
  if (!p) return;
  const box = p.parentElement;
  box.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${p.dataset.v}?autoplay=1" title="Vídeo" allow="autoplay; accelerometer; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
});
