<?php
session_start();
require __DIR__ . '/config.php';
// Valores padrão caso o config.php seja de uma versão antiga e não tenha estas linhas.
if (!defined('BASE_URL')) define('BASE_URL', 'http://localhost' . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\'));
if (!defined('YOUTUBE_KEY')) define('YOUTUBE_KEY', '');
if (!defined('RESEND_KEY')) define('RESEND_KEY', '');
if (!defined('DONO_EMAIL')) define('DONO_EMAIL', '');
function db() {
  static $p;
  if (!$p) $p = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
  return $p;
}
function logado() { return isset($_SESSION['uid']); }
function exige() { if (!logado()) { header('Location: login.php'); exit; } }
function e($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function favs() {
  if (!logado()) return [];
  $q = db()->prepare('SELECT conteudo_id FROM favoritos WHERE usuario_id=?');
  $q->execute([$_SESSION['uid']]);
  return array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));
}
function log_email($msg) { @file_put_contents(__DIR__ . '/email_erros.log', date('Y-m-d H:i:s') . ' ' . $msg . "\n", FILE_APPEND); }
// Envia e-mail pelo Resend. Se falhar, grava o motivo em email_erros.log (na pasta do site).
function enviar_email($para, $assunto, $html) {
  if (!function_exists('curl_init')) { log_email('A extensão curl do PHP não está ativada (php.ini: extension=curl).'); return false; }
  if (RESEND_KEY === '' || strpos(RESEND_KEY, 'COLE_') === 0) { log_email('RESEND_KEY não foi configurada no config.php.'); return false; }
  $c = curl_init('https://api.resend.com/emails');
  curl_setopt_array($c, [
    CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 10,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . RESEND_KEY, 'Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode(['from' => 'CRONOS <onboarding@resend.dev>', 'to' => [$para], 'subject' => $assunto, 'html' => $html]),
  ]);
  $r = curl_exec($c); $code = curl_getinfo($c, CURLINFO_HTTP_CODE); $err = curl_error($c); curl_close($c);
  if ($r === false) { log_email('Falha de conexão com o Resend: ' . $err); return false; }
  if ($code < 200 || $code >= 300) { log_email('Resend respondeu HTTP ' . $code . ': ' . $r); return false; }
  return true;
}
function avisar_dono($nome, $email) {
  return enviar_email(DONO_EMAIL, 'Novo cadastro no CRONOS',
    '<p>Nova conta criada.</p><p><b>Nome:</b> ' . e($nome) . '<br><b>E-mail:</b> ' . e($email) . '</p>');
}
function garantir_tabela_reset() {
  db()->exec('CREATE TABLE IF NOT EXISTS reset_senha (id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL, token_hash CHAR(64) NOT NULL, expira_em DATETIME NOT NULL, usado TINYINT NOT NULL DEFAULT 0, INDEX (token_hash), FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE)');
}
function topo($titulo) { ?>
<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titulo) ?> — CRONOS</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css"></head><body>
<header class="menu"><a class="logo" href="<?= logado() ? 'catalogo.php' : 'index.php' ?>">CRONOS</a>
<nav><?php if (logado()): ?><a href="catalogo.php">Catálogo</a><a href="favoritos.php">Favoritos</a><?php endif; ?></nav>
<div class="conta"><?php if (logado()): ?><span>Olá, <?= e($_SESSION['nome']) ?></span><a href="logout.php">Sair</a>
<?php else: ?><a href="login.php">Login</a><a class="btn peq" href="cadastro.php">Cadastrar</a><?php endif; ?></div></header>
<main>
<?php }
function rodape() { ?>
</main>
<footer class="rodape"><strong>CRONOS</strong> — O passado nunca esteve tão perto.<br>
<small>Projeto Express · SENAI São Paulo · Félix Guisard · Técnico em Desenvolvimento de Sistemas · 2026</small></footer>
<script>window.LOGADO=<?= logado() ? 'true' : 'false' ?>;window.FAVS=<?= json_encode(favs()) ?>;window.MODO=<?= json_encode($GLOBALS['modo'] ?? '') ?>;</script>
<script src="assets/data.js"></script><script src="assets/app.js"></script>
</body></html>
<?php }
