<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'chronos');
define('DB_USER', 'root');
define('DB_PASS', '');
define('RESEND_KEY', 're_3eE72DhA_FLL6ndofWiciaf24TgRHmn3h');
define('DONO_EMAIL', 'anabeatriz09.sesisenai@gmail.com');
define('BASE_URL', 'http://localhost/chronos');
