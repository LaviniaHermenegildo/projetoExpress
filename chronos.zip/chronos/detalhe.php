<?php require 'inc.php'; exige(); topo('Detalhes'); ?>
<section class="conteudo"><div id="detalhe"></div></section>
<?php rodape(); ?>
